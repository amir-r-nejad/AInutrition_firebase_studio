import { clsx, type ClassValue } from 'clsx';
import { formatDistance } from 'date-fns';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(
  value: number,
  options?: Intl.NumberFormatOptions
): string {
  return new Intl.NumberFormat('en-US', {
    style: 'decimal',
    ...options,
  }).format(value);
}

export function getTimeAgo({
  startDate,
  endDate,
  addSuffix = false,
}: {
  startDate: string | number | Date;
  endDate?: string | number | Date;
  addSuffix?: boolean;
}) {
  return formatDistance(startDate, endDate || Date.now(), {
    addSuffix,
  });
}

export function getURL() {
  let url =
    process?.env?.NEXT_PUBLIC_SITE_URL ??
    process?.env?.NEXT_PUBLIC_VERCEL_URL ??
    'http://localhost:3000/';

  url = url.startsWith('http') ? url : `https://${url}`;
  url = url.endsWith('/') ? url : `${url}/`;

  return url;
}

export function getAIApiErrorMessage(error: any): string {
  const genericMessage =
    'An unexpected error occurred with the AI service. Please try again later.';
  if (!error || !error.message || typeof error.message !== 'string') {
    return genericMessage;
  }

  const message = error.message as string;

  if (message.includes('503') || message.includes('overloaded')) {
    return 'The AI model is currently busy or unavailable. Please try again in a few moments.';
  }

  if (
    message.includes('403 Forbidden') ||
    message.includes('API_KEY_SERVICE_BLOCKED')
  ) {
    return 'AI API Error: Access is forbidden. Please check if your Google AI API key is correct and that the "Generative Language API" is enabled in your Google Cloud project.';
  }

  if (message.includes('400 Bad Request')) {
    return 'AI API Error: The request was malformed, which might be due to a temporary issue or invalid input. Please check your inputs and try again.';
  }

  if (message.includes('500 Internal Server Error')) {
    return 'AI API Error: The AI service is currently experiencing issues. Please try again later.';
  }

  return `AI Error: ${message.substring(0, 150)}${
    message.length > 150 ? '...' : ''
  }`;
}

export function formatValue(
  value: number | string | null | undefined,
  suffix = '',
  fallback = 'N/A',
  decimals = 1
) {
  if (value === null || value === undefined || value === '') return fallback;

  if (typeof value === 'number') {
    return value.toFixed(decimals) + suffix;
  }

  const numValue = parseFloat(String(value));
  if (!isNaN(numValue)) {
    return numValue.toFixed(decimals) + suffix;
  }

  return String(value) + suffix;
}

export function calculateProgress(
  current: number | undefined | null,
  target: number | undefined | null
) {
  if (!current || !target) return 0;
  return Math.min((current / target) * 100, 100);
}
