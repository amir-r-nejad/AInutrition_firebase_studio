import { ReactNode } from 'react';

function PDFlayout({ children }: { children: ReactNode }) {
  return <div>{children}</div>;
}

export default PDFlayout;
